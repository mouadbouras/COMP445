1- Make sure NodeJS is installed 
2- Start command line in folder
3- Excecute httpc commands preceded with 'node'
    Example: node httpc help

